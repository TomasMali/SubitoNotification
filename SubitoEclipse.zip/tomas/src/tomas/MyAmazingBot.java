package tomas;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import org.jsoup.nodes.Element;
import org.telegram.telegrambots.api.methods.send.SendMessage;
import org.telegram.telegrambots.api.methods.updatingmessages.EditMessageText;
import org.telegram.telegrambots.api.objects.Update;
import org.telegram.telegrambots.bots.TelegramLongPollingBot;
import org.telegram.telegrambots.exceptions.TelegramApiException;

import Utils.Annuncio;
import Utils.Consts;
import Utils.InlineKeyboardsBuilder;
import Utils.Jsoup_HTML;
import Utils.User;
import Utils.UserList;
import Utils.Utils;

public class MyAmazingBot extends TelegramLongPollingBot {
	public UserList userListObject = UserList.getInstanceUser();
	public List<User> user_List = userListObject.getUserList();
	User current_user = null;
	Jsoup_HTML Jsoup_HTML = new Jsoup_HTML();

	public  String citta = "";
	public String cerca = "";
	public String path = "https://www.subito.it/annunci-veneto/vendita/usato/" + citta + cerca;
	public float price;
	public String sms = "";
	 public  List<Annuncio> cache = new ArrayList<Annuncio>();
	 
		Runnable helloRunnable = new Runnable() {
			public void run() {
				executeOnTime();
			}
		};

		ScheduledExecutorService executor = Executors.newScheduledThreadPool(1);

	public String getBotUsername() {
		return "tomasmalibot";
	}

	@Override
	public String getBotToken() {
		// TODO Auto-generated method stub
		return "502596920:AAGXj1omTxPldCElns1Wiw965LqslMSKBHw";
	}

	public void onUpdateReceived(Update update) {
		// method that insert a user in the list if this one doesn't exsist
		current_user = new User(update);
		userListObject.addUser(current_user);
		// All the text message
		if (update.hasMessage())
			execHasMessage(update);
		else if (update.hasCallbackQuery())
			execHasCallbackQuery(update);
	}

	public void execHasMessage(Update update) {
		if (update.getMessage().hasText()) {
			switch (update.getMessage().getText()) {
			case Consts.Subito:
				getCitta(update);
				break;
			case Consts.Timer:
				giveMeNotification(update);
				break;
			case Consts.TIMEROFF:
				giveMeNotification(update);
				break;

			default:
				sms = update.getMessage().getText();
				checkIfSearch(update.getMessage().getText());
				break;
			}

		}
	}

	public void execHasCallbackQuery(Update update) {

		switch (current_user.getInlineKeyboardData().toLowerCase()) {
		case Consts.TUTTAPROVINCIA:
			citta = "";
			break;
		case Consts.BELLUNO:
			citta = Consts.BELLUNO;
			break;
		case Consts.PADOVA:
			this.citta = Consts.PADOVA;
			break;
		case Consts.ROVIGO:
			citta = Consts.ROVIGO;
			break;
		case Consts.TREVISO:
			citta = Consts.TREVISO;
			break;
		case Consts.VENEZIA:
			citta = Consts.VENEZIA;
			break;
		case Consts.VERONA:
			citta = Consts.VERONA;
			break;
		case Consts.VICENZA:
			citta = Consts.VICENZA;
			break;

		default:

			break;
		}

		EditMessageText new_message = current_user.composeTextToSendBack(
				"Scrivi '#' poi subito l'articolo che desideri cercare e premi invio");

		// new_message.setReplyMarkup(new InlineKeyboardsBuilder().composeInlineKeyboard_Prova2());

		try {
			execute(new_message);
		} catch (TelegramApiException e) {
			e.printStackTrace();
		}

	}

	public void getCitta(Update update) {

		SendMessage message = current_user.composeMessage("Scegli Città");

		message.setReplyMarkup(new InlineKeyboardsBuilder().composeInlineKeyboard_Citta());
		try {
			execute(message);
		} catch (TelegramApiException e) {
			e.printStackTrace();
		}
	}

	public void checkIfSearch(String aux) {
	
		if (aux.contains("#")) {
			try {
				cerca = aux.substring(1);
				path = "https://www.subito.it/annunci-veneto/vendita/usato/" + citta + "?q=" + URLEncoder.encode(aux.substring(1), "UTF-8") + "&";
			} catch (UnsupportedEncodingException e1) {
				e1.printStackTrace();
			}
			try {
				execute(current_user.composeMessage("Scrivi il prezzo massimo da cercare"));
			} catch (TelegramApiException e) {
				e.printStackTrace();
			}
		}
		if (Utils.isNumeric(aux)) {
			price = Float.parseFloat(aux);
			System.out.println("Sto cercando in: "+ path);
			List<Annuncio> list_an  = null;
			
			 try {
				list_an = Jsoup_HTML.getOggi(path, price,cache,true);
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			
			
			for(Annuncio an : list_an) {
				
				try {
					System.out.println(an.toString());
					SendMessage message = current_user.composeMessage(an.toString());
					
					execute(message);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			if(list_an.isEmpty()) {
				System.out.println("Nessun annuncio trovato !");
				SendMessage message = current_user.composeMessage("Nessun annuncio trovato !");
				
				try {
					execute(message);
				} catch (TelegramApiException e) {
					e.printStackTrace();
				}
			}
				
		
		}

	}
	public void executeOnTime() {
		List<Annuncio> list_an = null;
		
		
		try {
			 list_an = Jsoup_HTML.getOggi(path, price,cache,false);
				
			if(!list_an.isEmpty()) {
				
				for(Annuncio an : list_an) {
					SendMessage message = current_user.composeMessage(an.toString());
					execute(message);
				}

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void giveMeNotification(Update update) {
		
		

		
		
String sms_ = update.getMessage().getText();
		if(sms_.equals(Consts.Timer)) {
		try {
			
			
			
execute(current_user.composeMessage("Il sistema di notificazione giornaliera è attivato per ("+ cerca + ") a ("+citta+")" ));
executor.scheduleAtFixedRate(helloRunnable, 0, 20, TimeUnit.SECONDS);
			
			
		} catch (TelegramApiException e) {
			e.printStackTrace();
		}
		}else if(sms_.equals(Consts.TIMEROFF))
		{
			try {
				execute(current_user.composeMessage("Il sistema di notificazione per "+ "("+ cerca + ") a ("+citta+ ")"+ "è stato disattivato"));
				executor.shutdownNow();
			
			} catch (TelegramApiException e) {
				e.printStackTrace();
			}
			
		}

		
	}

}



