package Utils;

import java.util.List;

public class Utils {

	public static boolean isNumeric(String str) {
		return str.matches("[+-]?\\d*(\\.\\d+)?");
	}
	
	public static boolean isInCache(List<Annuncio> annunci, Annuncio a) {
		
		for(Annuncio an : annunci) {
			if(an.getTitolo().equals(a.getTitolo()) && an.getPrezzo().equals(a.getPrezzo()))
				return true;
		}
		
		return false;
	}
}
