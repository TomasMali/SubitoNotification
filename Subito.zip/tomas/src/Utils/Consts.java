package Utils;

public class Consts {

	public final static String SUBITO = "SUBITO";
	public final static String TIMER = "TIMER";
	public final static String TIMEROFF = "TIMER OFF";

	public final static String TUTTAPROVINCIA = "tutta la provincia";
	public final static String BELLUNO = "belluno";
	public final static String PADOVA = "padova";
	public final static String ROVIGO = "rovigo";
	public final static String TREVISO = "treviso";
	public final static String VENEZIA = "tenezia";
	public final static String VERONA = "verona";
	public final static String VICENZA = "vicenza";

}
