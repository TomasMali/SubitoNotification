package Utils;

public class Consts {

	public final static String Subito = "subito";
	public final static String subito = "subito";
	public final static String Timer = "Timer";
	public final static String timer = "timer";
	public final static String TIMEROFF = "Timer off";

	public final static String TUTTAPROVINCIA = "tutta la provincia";
	public final static String BELLUNO = "belluno";
	public final static String PADOVA = "padova";
	public final static String ROVIGO = "rovigo";
	public final static String TREVISO = "treviso";
	public final static String VENEZIA = "tenezia";
	public final static String VERONA = "verona";
	public final static String VICENZA = "vicenza";

}
