package Users;

import java.util.concurrent.ThreadLocalRandom;

import org.telegram.telegrambots.api.objects.Update;

import MyWeatherClasses.MyComposeSms;
import MyWeatherClasses.MyWeather;
import MyWeatherClasses.MyWeatherData;

public class Timer extends Thread {
	String citta = "";
	Update update = new Update();
	MyWeather my = new MyWeather();
	public boolean running = true;
	
	public Timer(String citta, Update update, MyWeather my){
		this.citta = citta;
		this.update = update;
		this.my = my;
	}

	public void run() {
		while(true) {
		System.out.println("Sto stampando");
		
		MyWeatherData	myweatherData = new MyWeatherData(citta);
		new MyComposeSms(my,update).composeMessage(myweatherData.toString());
		
		try {
			Thread.sleep(4320000);
			
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
	}
}
