package Users;

import java.util.concurrent.ThreadLocalRandom;

import org.telegram.telegrambots.api.objects.Update;

import MyWeatherClasses.MyComposeSms;
import MyWeatherClasses.MyWeather;
import MyWeatherClasses.MyWeatherData;

public class Timer extends Thread {
	String citta = "";
	Update update = new Update();
	MyWeather my = new MyWeather();
	public boolean running = true;
	String stato = "";
	
	public Timer(String citta,String stato, Update update, MyWeather my){
		this.citta = citta;
		this.update = update;
		this.my = my;
		this.stato  = stato;
	}

	public void run() {
		while(running) {

			
			
			if(MyWeatherData.checkWeather(citta, stato)) {
				MyWeatherData	myweatherData = new MyWeatherData(citta, stato.isEmpty()? "IT": stato.trim());
				new MyComposeSms(my,update).composeMessage(myweatherData.toString());
			}
			else {
				new MyComposeSms(my,update).composeMessage("Città non trovata! Fai una nuova ricerca poi scrivi Timer");
				running = false;
			}
			
		

		
		try {
			Thread.sleep(57600000);
			// 4320000
			// 1 ora = 3600000
			// 16 ore = 57600000
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		}
	}
}
