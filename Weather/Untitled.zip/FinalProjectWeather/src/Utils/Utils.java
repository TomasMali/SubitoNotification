package Utils;

import java.util.List;

import Users.User;

public class Utils {
	
	public static boolean checkUser(User user, List<User> list) {
		
		for(User userAux : list) {
		if(userAux.getUserId() == user.getUserId())
			return true;
		}
			
			
		return false;
	}
	
	public static User getUser(long userId,List<User> list ) {
		
		for(User userAux : list) {
			if(userAux.getUserId() == userId)
				return userAux;
			}	
			return null;
	}

}
