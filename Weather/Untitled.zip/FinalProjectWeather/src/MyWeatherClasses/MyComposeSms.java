package MyWeatherClasses;

import org.telegram.telegrambots.api.methods.send.SendMessage;
import org.telegram.telegrambots.api.methods.updatingmessages.EditMessageText;
import org.telegram.telegrambots.api.objects.Update;
import org.telegram.telegrambots.exceptions.TelegramApiException;

public class MyComposeSms extends  MyWeather{
	
	MyWeather instant = new MyWeather();
	Update update = null;
	
	public MyComposeSms(MyWeather instant, Update update){
		this.instant = instant;
		this.update = update;
	}
	

	

public void composeMessage(String text) {
	
	EditMessageText message1 = null;
	SendMessage message2 = null;
	
	if(!update.hasMessage()) {
	
	 message1 =  new EditMessageText()
            .setChatId(update.getCallbackQuery().getMessage().getChatId())
            .setMessageId( (int) (update.getCallbackQuery().getMessage().getMessageId()))
            .setText(text);
	}
	else {
		message2 = new SendMessage() 
        .setChatId(update.getMessage().getChatId())
        .setText(text);
	}
	
	try {
		if(!update.hasMessage())
		execute(message1);
		else
			execute(message2);
	} catch (TelegramApiException e) {
		e.printStackTrace();
	}
}

}

