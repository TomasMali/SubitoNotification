package MyWeatherClasses;

import il.ac.hit.finalproject.classes.IWeatherDataService;
import il.ac.hit.finalproject.classes.Location;
import il.ac.hit.finalproject.classes.WeatherData;
import il.ac.hit.finalproject.classes.WeatherDataServiceFactory;
import il.ac.hit.finalproject.classes.WeatherDataServiceFactory.service;
import il.ac.hit.finalproject.exceptions.WeatherDataServiceException;

public class MyWeatherData {
	


	private String Stato = "";
	private String TemperaturaAttuale = "";
	private String TemperaturaMinima = "";
	private String TemperaturaMassima = "";
	private String Umidità = "";
	private String UltimiAggiornamenti = "";
	private String citta = "";
	public boolean cittaTrovata = true;
	private String citty = "";

	
	public static boolean checkWeather(String citty) {
		IWeatherDataService dataService = WeatherDataServiceFactory.getWeatherDataService(service.OPEN_WEATHER_MAP);
		WeatherData data = null;
		boolean x = false;
		try
		{
			data = dataService.getWeatherData(new Location(citty, "IT"));
			if(data.getSpeed() != null) {
				x = true;
			}
					
		} catch (WeatherDataServiceException e)
		{
			e.printStackTrace();
		}
		return x;
	}
   

	
	public MyWeatherData(String citta) {
		
		IWeatherDataService dataService = WeatherDataServiceFactory.getWeatherDataService(service.OPEN_WEATHER_MAP);
		WeatherData data = null;
		try
		{
			data = dataService.getWeatherData(new Location(citta, "IT"));
			System.out.println(data.toString());		
		} catch (WeatherDataServiceException e)
		{
			
			e.printStackTrace();
		}

	
		String cielo = data.getClouds().toString();
		Stato = cielo.toString().contains("clear sky") ? cielo + " "+  "\u2600\ufe0f": cielo.toString().contains("few clouds") ? cielo.toString() + "\u26c5\ufe0f" : "";
		TemperaturaAttuale = data.getTemperature().getValue().toString();
		TemperaturaMassima = data.getTemperature().getMax().toString();
		TemperaturaMinima = data.getTemperature().getMin().toString();
		Umidità = data.getHumidity().toString();
		UltimiAggiornamenti = data.getLastUpdate().getValue().toString();
		citty = data.getCity().toString();
		this.citta = citta;
		

	}
	

	
	public String getStato() {
		return Stato;
	}

	public String getTemperaturaAttuale() {
		return TemperaturaAttuale;
	}
	
	public String getTemperaturaMinima() {
		return TemperaturaMinima;
	}

	public String getTemperaturaMassima() {
		return TemperaturaMassima;
	}

	public String getUmidità() {
		return Umidità;
	}

	public String getUltimiAggiornamenti() {
		return UltimiAggiornamenti;
	}

	@Override
	public String toString() {
		return "°°°°°Il meteo a "+ citta.toUpperCase()+"°°°°°"+ "\n"+ "Nuovole=" + Stato + "\n" + "TemperaturaAttuale=" + TemperaturaAttuale +  "\n" + "TemperaturaMinima="
				+ TemperaturaMinima + "\n" + "TemperaturaMassima=" + TemperaturaMassima + "\n" + "Umidità=" + Umidità
				+ "\n" +  "UltimiAggiornamenti=" + UltimiAggiornamenti ;
	}
	

}
