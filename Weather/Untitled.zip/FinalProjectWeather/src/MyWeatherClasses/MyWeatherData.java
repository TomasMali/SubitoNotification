package MyWeatherClasses;

import java.io.FileNotFoundException;

import il.ac.hit.finalproject.classes.IWeatherDataService;
import il.ac.hit.finalproject.classes.Location;
import il.ac.hit.finalproject.classes.WeatherData;
import il.ac.hit.finalproject.classes.WeatherDataServiceFactory;
import il.ac.hit.finalproject.classes.WeatherDataServiceFactory.service;
import il.ac.hit.finalproject.exceptions.WeatherDataServiceException;

public class MyWeatherData {
	


	private String Stato = "";
	private String TemperaturaAttuale = "";
	private String TemperaturaMinima = "";
	private String TemperaturaMassima = "";
	private String Umidità = "";
	private String UltimiAggiornamenti = "";
	private String citta = "";
	public boolean cittaTrovata = true;
	private String citty = "";
	
	private static String CLEARSKY  = "\u2600\ufe0f";
	private static String FEWCLOUDS  = "\u26c5\ufe0f";  
	private static String SCATTEREDCLOUDS  = "\ud83c\udf25";   
	private static String SHOWERRAIN  = "\ud83c\udf26";   
	private static String RAIN  = "\u2614\ufe0f";   
	private static String THUNDERSTORM  = "\u26a1\ufe0f";    
	private static String SNOW  = "\u2744\ufe0f";

	

	
	public static boolean checkWeather(String citty, String stato) {
		IWeatherDataService dataService = WeatherDataServiceFactory.getWeatherDataService(service.OPEN_WEATHER_MAP);
		WeatherData data = null;
	
	
			try {
				data = dataService.getWeatherData(new Location(citty, stato.isEmpty()? "IT" :stato.trim() ));
				if(data == null)
					return false;
			} catch (WeatherDataServiceException e) {
				
				e.printStackTrace();
			}
	
			
		return true;
	}
   

	
	public MyWeatherData(String citta, String stato) {
		
		IWeatherDataService dataService = WeatherDataServiceFactory.getWeatherDataService(service.OPEN_WEATHER_MAP);
		WeatherData data = new WeatherData();
		try
		{
			data = dataService.getWeatherData(new Location(citta, stato.isEmpty()? "IT": stato.trim()));
			System.out.println(data.toString());		
		} catch (WeatherDataServiceException e)
		{
			
			e.printStackTrace();
		}

	
		String cielo = data.getClouds().toString();
		Stato = cielo.toString().contains("clear sky") ? cielo + " "+  CLEARSKY: cielo.toString().contains("few clouds") ? cielo.toString() + FEWCLOUDS :
			cielo.toString().contains("scattered clouds") || cielo.toString().contains("broken clouds")  ? cielo.toString() + SCATTEREDCLOUDS : cielo.toString().contains("shower") ?
					cielo.toString() + SHOWERRAIN :  cielo.toString().contains("thunder") ?
							cielo.toString() + THUNDERSTORM :  cielo.toString().contains("rain") ? cielo.toString() + RAIN :  cielo.toString().contains("snow") || cielo.toString().contains("mist")  ? cielo.toString() + SNOW : "";
		TemperaturaAttuale = data.getTemperature().getValue().toString();
		TemperaturaMassima = data.getTemperature().getMax().toString();
		TemperaturaMinima = data.getTemperature().getMin().toString();
		Umidità = data.getHumidity().toString();
		UltimiAggiornamenti = data.getLastUpdate().getValue().toString();
		citty = data.getCity().toString();
		this.citta = citta;

	}
	

	
	public String getStato() {
		return Stato;
	}

	public String getTemperaturaAttuale() {
		return TemperaturaAttuale;
	}
	
	public String getTemperaturaMinima() {
		return TemperaturaMinima;
	}

	public String getTemperaturaMassima() {
		return TemperaturaMassima;
	}

	public String getUmidità() {
		return Umidità;
	}

	public String getUltimiAggiornamenti() {
		return UltimiAggiornamenti;
	}

	@Override
	public String toString() {
		return "°°°°°Il meteo a "+ citta.toUpperCase()+"°°°°°"+ "\n"+ "Nuvole=" + Stato + "\n" + "TemperaturaAttuale=" + TemperaturaAttuale +  "\n" + "TemperaturaMinima="
				+ TemperaturaMinima + "\n" + "TemperaturaMassima=" + TemperaturaMassima + "\n" + "Umidità=" + Umidità
				+ "\n" +  "UltimiAggiornamenti=" + UltimiAggiornamenti ;
	}
	

}
