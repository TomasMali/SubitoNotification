package MyWeatherClasses;

import org.telegram.telegrambots.api.methods.send.SendMessage;
import org.telegram.telegrambots.api.objects.Update;
//import org.telegram.telegrambots.api.objects.User;
import org.telegram.telegrambots.bots.TelegramLongPollingBot;
import org.telegram.telegrambots.exceptions.TelegramApiException;

import Users.Timer;
import Users.User;
import il.ac.hit.finalproject.classes.IWeatherDataService;
import il.ac.hit.finalproject.classes.Location;
import il.ac.hit.finalproject.classes.WeatherData;
import il.ac.hit.finalproject.classes.WeatherDataServiceFactory;
import il.ac.hit.finalproject.classes.WeatherDataServiceFactory.service;
import il.ac.hit.finalproject.exceptions.WeatherDataServiceException;

public class MyWeather extends TelegramLongPollingBot  {
	public MyWeatherData myweatherData = null;
	Timer x = null;
	
	@Override
	public String getBotToken() {
		return "502596920:AAGXj1omTxPldCElns1Wiw965LqslMSKBHw";
	}


	public String getBotUsername() {
		return "tomasmalibot";
	//	tomasmalibot
	//	502596920:AAGXj1omTxPldCElns1Wiw965LqslMSKBHw
    //  TomasSubitoBot
	//  657809545:AAEA4xHiTKLndDuRJc9G5XYrwt-ul2WFqH0
		
	}

	@Override
	public void onUpdateReceived(Update update) {
		
		if (update.hasMessage())
			HasMessage(update);
		else if (update.hasCallbackQuery())
			HasCallbackQuery(update);
		

		
	}

	
	// Gestione dei messaggio 
	private void HasMessage(Update update) {
		 String cittaData = update.getMessage().getText();
		if (update.getMessage().hasText()) {
			if(cittaData.contains("#")) {
			//	if(MyWeatherData.checkWeather(cittaData.substring(1))) {
				myweatherData = new MyWeatherData(cittaData.substring(1));
				new MyComposeSms(this,update).composeMessage(myweatherData.toString());
//				}
//				else
//					new MyComposeSms(this,update).composeMessage("Città non trovata!");
			}
			else
			switch (update.getMessage().getText()) {
			case "/start":
				  new MyComposeSms(this,update).composeMessage("Scrivi '#' poi subito il nome della città");
				break;
			case "Timer":
				  x = new Timer(cittaData.substring(1), update,this);
				 x.start();
				break;
			case "Timer off":
				 x.running = false;
				 x.interrupt();
				
		
				break;

			default:
				new MyComposeSms(this,update).composeMessage("\n"+ "Clicka /start per andare nella pagina principale");
				break;
			}

		}
	}
	// Gestione CallBack
	private void HasCallbackQuery(Update update) {
		
	}


}
