package tomas;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import org.telegram.telegrambots.api.methods.send.SendMessage;
import org.telegram.telegrambots.api.methods.updatingmessages.EditMessageText;
import org.telegram.telegrambots.api.objects.Update;
import org.telegram.telegrambots.bots.TelegramLongPollingBot;
import org.telegram.telegrambots.exceptions.TelegramApiException;

import Utils.Annuncio;
import Utils.Consts;
import Utils.InlineKeyboardsBuilder;
import Utils.Jsoup_HTML;
import Utils.User;
import Utils.UserList;
import Utils.Utils;

public class MyAmazingBot extends TelegramLongPollingBot {
	public UserList userListObject = UserList.getInstanceUser();
	public List<User> user_List = userListObject.getUserList();
	User current_user = null;
	Jsoup_HTML Jsoup_HTML = new Jsoup_HTML();
	String parola = "";
	public String citta = "";
	public String cerca = "";
	public String path = "https://www.subito.it/annunci-veneto/vendita/usato/" + citta + cerca;
	public List<Float> price = new ArrayList<>();
	public List<Float> price_Timer = new ArrayList<>();
	public String sms = "";
	public List<Annuncio> cache = new ArrayList<Annuncio>();
	public boolean statoTimer = false;

	Runnable helloRunnable = new Runnable() {
		public void run() {
			System.out.println("Timer attivo alle: " + LocalDateTime.now());
			executeOnTime();
		}
	};

	ScheduledExecutorService executor = Executors.newScheduledThreadPool(1);

	public String getBotUsername() {
		return "TomasSubitoBot";
	//	tomasmalibot
	//	502596920:AAGXj1omTxPldCElns1Wiw965LqslMSKBHw
    //  TomasSubitoBot
	//  657809545:AAEA4xHiTKLndDuRJc9G5XYrwt-ul2WFqH0
		
	}

	@Override
	public String getBotToken() {
		return "657809545:AAEA4xHiTKLndDuRJc9G5XYrwt-ul2WFqH0";
	}

	public void onUpdateReceived(Update update) {
		// method that insert a user in the list if this one doesn't exsist
		current_user = new User(update);
		System.out.println("Nome: " + current_user.getFirstName() + "\n" + "Cognome: ");
		// System.out.println(update.getMessage().getText());
		userListObject.addUser(current_user);
		// All the text message
		if (update.hasMessage())
			execHasMessage(update);
		else if (update.hasCallbackQuery())
			execHasCallbackQuery(update);
	}

	public void execHasMessage(Update update) {
		if (update.getMessage().hasText()) {
			switch (update.getMessage().getText()) {
			case Consts.Subito:
				getCitta(update);
				break;
			case Consts.Timer:
				giveMeNotification(update);
				break;
			case Consts.TIMEROFF:
				giveMeNotification(update);
				break;

			default:
				sms = update.getMessage().getText();
				checkIfSearch(update.getMessage().getText());
				break;
			}

		}
	}

	public void execHasCallbackQuery(Update update) {

		switch (current_user.getInlineKeyboardData().toLowerCase()) {
		case Consts.TUTTAPROVINCIA:
			citta = "";
			break;
		case Consts.BELLUNO:
			citta = Consts.BELLUNO;
			break;
		case Consts.PADOVA:
			this.citta = Consts.PADOVA;
			break;
		case Consts.ROVIGO:
			citta = Consts.ROVIGO;
			break;
		case Consts.TREVISO:
			citta = Consts.TREVISO;
			break;
		case Consts.VENEZIA:
			citta = Consts.VENEZIA;
			break;
		case Consts.VERONA:
			citta = Consts.VERONA;
			break;
		case Consts.VICENZA:
			citta = Consts.VICENZA;
			break;

		default:

			break;
		}

		EditMessageText new_message = current_user.composeTextToSendBack(
				"Scrivi '#' poi subito l'articolo che desideri cercare e premi invio");


		try {
			execute(new_message);
		} catch (TelegramApiException e) {
			e.printStackTrace();
		}

	}

	public void getCitta(Update update) {

		SendMessage message = current_user.composeMessage("Scegli Città");

		message.setReplyMarkup(new InlineKeyboardsBuilder().composeInlineKeyboard_Citta());
		try {
			execute(message);
		} catch (TelegramApiException e) {
			e.printStackTrace();
		}
	}

	public void checkIfSearch(String aux) {

		if (aux.contains("#")) {
			cerca = aux.substring(1);
			System.out.println(cerca);
			parola = cerca;
			path = "https://www.subito.it/annunci-veneto/vendita/informatica/" + citta + "?q=";
			try {
				execute(current_user.composeMessage("Scrivi il prezzo massimo da cercare"));
			} catch (TelegramApiException e) {
				e.printStackTrace();
			}
		}
		List<String> list = Arrays.asList(aux.split(","));
		
		
		if (Utils.isNumeric(list) ) {
			
			if(list.size() != Arrays.asList(parola.split(",")).size()) {
				try {
					execute(current_user.composeMessage("Attenzione, il nuomero degli annunci che vuoi cercare non corrisponde con il numero dei prezzi separati con la virgola!"));
				} catch (TelegramApiException e) {
					e.printStackTrace();
				}
				return;
			}
		
			for(String s : list) {
				System.out.println("prezzo: "+ s);
				price.add(Float.parseFloat(s.trim()));
				
			}
			
		
			System.out.println("Sto cercando in: " + path + " Con prezzi: "+ price);
			List<Annuncio> list_an = new ArrayList<>();

			try {

				System.out.println("i:  :" + parola);
				list_an = Jsoup_HTML.getOggi(parola, path, price, cache, true);
				price_Timer = new ArrayList<Float>(price);
			
				price.clear();
			} catch (IOException e1) {
				e1.printStackTrace();
			}

			for (Annuncio an : list_an) {

				try {
					System.out.println(an.toString());
					SendMessage message = current_user.composeMessage(an.toString());

					execute(message);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			if (list_an.isEmpty()) {
				System.out.println("Nessun annuncio trovato !");
				SendMessage message = current_user.composeMessage("Nessun annuncio trovato !");

				try {
					execute(message);
				} catch (TelegramApiException e) {
					e.printStackTrace();
				}
			}

		}

	}

	public void executeOnTime() {
		List<Annuncio> list_an = null;

		try {
		
			list_an = Jsoup_HTML.getOggi(parola, path, price_Timer, cache, false);
			if(!statoTimer)
			price_Timer.clear();
			if (!list_an.isEmpty()) {

				for (Annuncio an : list_an) {
					SendMessage message = current_user.composeMessage(an.toString());
					execute(message);
				}

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void giveMeNotification(Update update) {


if(statoTimer) {
	try {
		execute(current_user.composeMessage("Attenzione hai gia attivato le notifiche per: " + cerca + "\n" + "Devi scrivere 'Timer off' prima di attivarlo di nuovo!"));
		executor.shutdownNow();
	} catch (TelegramApiException e) {
		e.printStackTrace();
	}
	return;
}
else
	statoTimer = true;


		String sms_ = update.getMessage().getText();
		if (sms_.equals(Consts.Timer) && !cerca.isEmpty()) {
			try {
				System.out.println("Il sistema di notificazione per '" + cerca + "' è stato attivato");
				execute(current_user.composeMessage("Il sistema di notificazione per '" + cerca
						+ "' è stato attivato"));
				executor.scheduleAtFixedRate(helloRunnable, 0, 20, TimeUnit.MINUTES);

			} catch (TelegramApiException e) {
				e.printStackTrace();
			}
		} else if (sms_.equals(Consts.TIMEROFF) && !cerca.isEmpty()) {
			
			statoTimer = false;
			
			try {
				System.out.println("Il sistema di notificazione per '" + cerca + "' è stato disattivato");
				execute(current_user.composeMessage("Il sistema di notificazione per '" + cerca
						+ "' è stato  disattivato"));
				executor.shutdownNow();

			} catch (TelegramApiException e) {
				e.printStackTrace();
			}

		}

	}

}
