package MyWeatherClasses;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.telegram.telegrambots.api.methods.send.SendMessage;
import org.telegram.telegrambots.api.objects.Update;
//import org.telegram.telegrambots.api.objects.User;
import org.telegram.telegrambots.bots.TelegramLongPollingBot;
import org.telegram.telegrambots.exceptions.TelegramApiException;

import Users.Timer;
import Users.User;
import Utils.Utils;
import il.ac.hit.finalproject.classes.IWeatherDataService;
import il.ac.hit.finalproject.classes.Location;
import il.ac.hit.finalproject.classes.WeatherData;
import il.ac.hit.finalproject.classes.WeatherDataServiceFactory;
import il.ac.hit.finalproject.classes.WeatherDataServiceFactory.service;
import il.ac.hit.finalproject.exceptions.WeatherDataServiceException;

public class MyWeather extends TelegramLongPollingBot  {
	public MyWeatherData myweatherData = null;
	private List<User> list = new ArrayList<User>();

	
	@Override
	public String getBotToken() {
		return "502596920:AAGXj1omTxPldCElns1Wiw965LqslMSKBHw";
	}


	public String getBotUsername() {
		return "tomasmalibot";
	//	tomasmalibot
	//	502596920:AAGXj1omTxPldCElns1Wiw965LqslMSKBHw
    //  TomasSubitoBot
	//  657809545:AAEA4xHiTKLndDuRJc9G5XYrwt-ul2WFqH0
		
	}

	@Override
	public void onUpdateReceived(Update update) {
		
		User current = new User(this,update);
		if(!Utils.checkUser(current, list))
			list.add(current);
		
		
		if (update.hasMessage())
			HasMessage(update);
		else if (update.hasCallbackQuery())
			HasCallbackQuery(update);
		

		
	}

	
	// Gestione dei messaggio 
	private void HasMessage(Update update) {
		 String cittaData = update.getMessage().getText();
		// System.out.println("Longitude: "+ update.getMessage().getLocation().getLatitude());
		

		 if (update.getMessage().hasText()) {
			 
			 List<String> listSplit = Arrays.asList(cittaData.split(","));
			 cittaData = listSplit.get(0);
			 String stato = listSplit.size()>1 ? listSplit.get(1) : "";
			if(cittaData.contains("#")) {
				Utils.getUser(update.getMessage().getChat().getId(), list).setCitta(cittaData.substring(1));
				Utils.getUser(update.getMessage().getChat().getId(), list).setStato(stato);
				
				if(MyWeatherData.checkWeather(cittaData.substring(1),stato)) {
				myweatherData = new MyWeatherData(cittaData.substring(1),stato);
				new MyComposeSms(this,update).composeMessage(myweatherData.toString());
				}
				else 
					new MyComposeSms(this,update).composeMessage("Città non trovata!");
			}
			else
			switch (update.getMessage().getText().toUpperCase()) {
			case "/START":
				  new MyComposeSms(this,update).composeMessage("Scrivi '#' poi subito il nome della città da cercare. Solo se vuoi cercare nei paesi esteri scrivi ad esempio: #berlino,DE");
				break;
			case "TIMER":
				  Utils.getUser(update.getMessage().getChat().getId(), list).timer = new Timer(Utils.getUser(update.getMessage().getChat().getId(), list).getCitta(),Utils.getUser(update.getMessage().getChat().getId(), list).getStato(), update,this);
				  Utils.getUser(update.getMessage().getChat().getId(), list).timer.start();
				break;
			case "TIMER OFF":
				 Utils.getUser(update.getMessage().getChat().getId(), list).timer.running = false;
				 new MyComposeSms(this,update).composeMessage("Il sistema di notificazione è stato disabilitato! Clicka /start per andare nella pagina principale ");
		
				break;

			default:
				new MyComposeSms(this,update).composeMessage("\n"+ "Clicka /start per andare nella pagina principale");
				break;
			}

		}
	}
	// Gestione CallBack
	private void HasCallbackQuery(Update update) {
		
	}


}
