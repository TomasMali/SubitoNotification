package Users;




import org.telegram.telegrambots.api.methods.send.SendMessage;
import org.telegram.telegrambots.api.methods.updatingmessages.EditMessageText;
import org.telegram.telegrambots.api.objects.Update;
import org.telegram.telegrambots.exceptions.TelegramApiException;

import MyWeatherClasses.MyWeather;

public  class User extends  MyWeather{
	
	private String firstName = "";
	private String lastName = "";
	private long chatId = 0;
	private long userId = 0;
	private String messageText = "";
	long message_id = 0;
    long chat_id = 0;
    private String inlineKeyboardData = "";
    private String citta = "";
    private String stato = "";
    private boolean timerStatus = false;
    
    MyWeather instant = new MyWeather();;
	Update update = new Update();
	public Timer timer = null;
	
	
   
	
	


	public User(MyWeather instant,Update update) {
		this.instant = instant;
		this.update = update;
		if(update.hasMessage()) {
			firstName = update.getMessage().getChat().getFirstName();
			lastName =  update.getMessage().getChat().getLastName();
			chatId = update.getMessage().getChatId();
			userId = update.getMessage().getChat().getId();
			messageText = update.getMessage().getText();
		}else
			if(update.hasCallbackQuery()) {
				firstName = update.getCallbackQuery().getMessage().getChat().getFirstName();
				lastName =  update.getCallbackQuery().getMessage().getChat().getLastName();
				chatId = update.getCallbackQuery().getMessage().getChatId();
				userId = update.getCallbackQuery().getMessage().getChat().getId();
				messageText = update.getCallbackQuery().getMessage().getText();
				
				message_id = update.getCallbackQuery().getMessage().getMessageId();
				chat_id = update.getCallbackQuery().getMessage().getChatId();
				inlineKeyboardData = update.getCallbackQuery().getData();
			}
		
	}
	
	public String getStato() {
		return stato;
	}

	public void setStato(String stato) {
		this.stato = stato;
	}

	public void composeMessage(String text) {
		
		EditMessageText message1 = null;
		SendMessage message2 = null;
		
		if(!update.hasMessage()) {
		
		 message1 =  new EditMessageText()
	            .setChatId(update.getCallbackQuery().getMessage().getChatId())
	            .setMessageId( (int) (update.getCallbackQuery().getMessage().getMessageId()))
	            .setText(text);
		}
		else {
			message2 = new SendMessage() 
	        .setChatId(update.getMessage().getChatId())
	        .setText(instant.myweatherData.toString());
		}
		
		try {
			if(!update.hasMessage())
			execute(message1);
			else
				execute(message2);
		} catch (TelegramApiException e) {
			e.printStackTrace();
		}
	}

	public long getMessage_id() {
		return message_id;
	}

	public void setMessage_id(long message_id) {
		this.message_id = message_id;
	}

	public long getChat_id() {
		return chat_id;
	}

	public void setChat_id(long chat_id) {
		this.chat_id = chat_id;
	}




	public String getInlineKeyboardData() {
		return inlineKeyboardData;
	}

	public void setInlineKeyboardData(String inlineKeyboardData) {
		this.inlineKeyboardData = inlineKeyboardData;
	}

	public String getFirstName() {
		return firstName;
	}


	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}


	public String getLastName() {
		return lastName;
	}


	public void setLastName(String lastName) {
		this.lastName = lastName;
	}


	public long getChatId() {
		return chatId;
	}


	public void setChatId(long chatId) {
		this.chatId = chatId;
	}


	public long getUserId() {
		return userId;
	}


	public void setUserId(long userId) {
		this.userId = userId;
	}

	
	

	public String getMessageText() {
		return messageText;
	}


	public void setMessageText(String messageText) {
		this.messageText = messageText;
	}
	
	public String getCitta() {
		return citta;
	}

	public void setCitta(String citta) {
		this.citta = citta;
	}

	public boolean getTimerStatus() {
		return timerStatus;
	}

	public void setTimerStatus(boolean timerStatus) {
		this.timerStatus = timerStatus;
	}
	


}
